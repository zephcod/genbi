import { Box } from "@chakra-ui/react";
import SolBi from "./sections/sol_bi";
import WithSubnavigation from "../components/navbar";
import LargeWithNewsletter from "../components/footer";
import Head from "next/head";

export default function BuilderInformatics(){
    return(
        <Box>
            <Head>
                <title>Gennbi Builder Informatics</title>
            </Head>
            <WithSubnavigation/>
            <SolBi/>
            <LargeWithNewsletter/>
        </Box>
    )
}