"use strict";
exports.id = 2924;
exports.ids = [2924];
exports.modules = {

/***/ 2924:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ SplitWithImage2)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@chakra-ui/react"
var react_ = __webpack_require__(8930);
// EXTERNAL MODULE: external "react-icons/io5"
var io5_ = __webpack_require__(9989);
;// CONCATENATED MODULE: ./public/bis.jpg
/* harmony default export */ const bis = ({"src":"/_next/static/media/bis.e05a0051.jpg","height":720,"width":1280,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAAkAf/xAAcEAACAgIDAAAAAAAAAAAAAAABAgMEETIAEzH/2gAIAQEAAT8ANsUqVyAQo5mrwIHbZOzOpXHnP//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQIBAT8Af//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQMBAT8Af//Z"});
;// CONCATENATED MODULE: ./pages/sections/column2_feature.tsx




const Feature = ({ text , icon , iconBg  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Stack, {
        direction: 'row',
        align: 'center',
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(react_.Flex, {
                w: 8,
                h: 8,
                align: 'center',
                justify: 'center',
                rounded: 'full',
                bg: iconBg,
                children: icon
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                fontWeight: 600,
                children: text
            })
        ]
    }));
};
function SplitWithImage2() {
    return(/*#__PURE__*/ jsx_runtime_.jsx(react_.Container, {
        maxW: '5xl',
        py: 20,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.SimpleGrid, {
            templateColumns: {
                sm: '1fr 1fr',
                md: '4fr 2fr'
            },
            columns: {
                base: 1,
                md: 2
            },
            spacing: 6,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(react_.Flex, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Image, {
                        rounded: 'md',
                        alt: 'Builder informatics',
                        objectFit: 'cover',
                        src: bis.src
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Stack, {
                    spacing: 4,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Heading, {
                            children: "Builder informatics"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Text, {
                            color: 'gray.500',
                            fontSize: 'lg',
                            children: [
                                "Gennbi compiles construction projects in to a coordinated informatics that involves hundreds of activities with logistical considerations and moving variables...",
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Button, {
                                    as: react_.Link,
                                    href: 'bis',
                                    variant: 'link',
                                    colorScheme: 'yellow',
                                    size: 'sm',
                                    children: "Learn more"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Stack, {
                            spacing: 4,
                            divider: /*#__PURE__*/ jsx_runtime_.jsx(react_.StackDivider, {
                                borderColor: (0,react_.useColorModeValue)('gray.100', 'gray.700')
                            }),
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(Feature, {
                                    icon: /*#__PURE__*/ jsx_runtime_.jsx(react_.Icon, {
                                        as: io5_.IoStatsChartSharp,
                                        color: (0,react_.useColorModeValue)('yellow.400', 'yellow.200'),
                                        w: 5,
                                        h: 5
                                    }),
                                    iconBg: (0,react_.useColorModeValue)('gray.100', 'gray.700'),
                                    text: 'Cash flow analysis'
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(Feature, {
                                    icon: /*#__PURE__*/ jsx_runtime_.jsx(react_.Icon, {
                                        as: io5_.IoCalendar,
                                        color: (0,react_.useColorModeValue)('yellow.400', 'yellow.200'),
                                        w: 5,
                                        h: 5
                                    }),
                                    iconBg: (0,react_.useColorModeValue)('gray.100', 'gray.700'),
                                    text: 'Logistics & schedule review'
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(Feature, {
                                    icon: /*#__PURE__*/ jsx_runtime_.jsx(react_.Icon, {
                                        as: io5_.IoWarning,
                                        color: (0,react_.useColorModeValue)('yellow.400', 'yellow.200'),
                                        w: 5,
                                        h: 5
                                    }),
                                    iconBg: (0,react_.useColorModeValue)('gray.100', 'gray.700'),
                                    text: 'Risk mitigation'
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    }));
};


/***/ })

};
;