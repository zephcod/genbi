"use strict";
exports.id = 1789;
exports.ids = [1789];
exports.modules = {

/***/ 1789:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ CallToActionWithAnnotation)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@chakra-ui/react"
var react_ = __webpack_require__(8930);
;// CONCATENATED MODULE: ./public/gennbi_enn.jpg
/* harmony default export */ const gennbi_enn = ({"src":"/_next/static/media/gennbi_enn.cb9e9479.jpg","height":5000,"width":5000,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABwEBAQAAAAAAAAAAAAAAAAAAAgP/2gAMAwEAAhADEAAAAKOKH//EABoQAAICAwAAAAAAAAAAAAAAAAECABEEEmH/2gAIAQEAAT8AfJCWjbCuT//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQIBAT8Af//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQMBAT8Af//Z"});
;// CONCATENATED MODULE: ./pages/sections/cta_headline.tsx



function CallToActionWithAnnotation() {
    return(/*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Container, {
            maxW: '6xl',
            h: '100%',
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.SimpleGrid, {
                    columns: {
                        base: 1,
                        md: 2
                    },
                    spacing: 10,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Stack, {
                            as: react_.Box,
                            textAlign: 'center',
                            spacing: {
                                base: 6,
                                md: 8
                            },
                            py: {
                                base: 6,
                                md: 8
                            },
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Heading, {
                                    fontWeight: 400,
                                    fontSize: {
                                        base: '2xl',
                                        sm: '3xl',
                                        md: '5xl'
                                    },
                                    lineHeight: '110%',
                                    children: [
                                        "Save your project",
                                        /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                            as: 'span',
                                            children: "from unchecked errors."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                    color: 'gray.500',
                                    children: "There are many inherent risks in every construction project that must be managed along the way. Contracts, standards, compliance, materials and safety are among the few that Gennbi ensures to highlight and prevent from happening."
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
                                    flex: 1,
                                    bg: 'red',
                                    width: '100%'
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Stack, {
                            direction: 'column',
                            spacing: 3,
                            align: 'center',
                            alignSelf: 'center',
                            position: 'relative',
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.FormControl, {
                                    display: "flex",
                                    alignSelf: "center",
                                    alignItems: "center",
                                    paddingTop: 4,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(react_.FormLabel, {
                                            htmlFor: "email-alerts",
                                            mb: "0",
                                            children: "Enable email alerts?"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Switch, {
                                            size: "lg",
                                            id: "email-alerts"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Flex, {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
                                        p: 6,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Image, {
                                            w: '90%',
                                            rounded: 'md',
                                            alt: 'Engineering neural networks',
                                            objectFit: 'cover',
                                            src: gennbi_enn.src
                                        })
                                    })
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Flex, {
                    p: 6,
                    maxW: 'sm',
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Button, {
                            as: react_.Link,
                            colorScheme: "yellow",
                            bgGradient: "linear(yellow.200, yellow.300)",
                            color: 'black',
                            fontWeight: 500,
                            href: 'http://localhost/gennbi/',
                            boxShadow: '0px 1px 25px -5px rgb(236 200 50 / 48%), 0 10px 10px -5px rgb(236 200 50 / 43%)',
                            _hover: {
                                textDecoration: 'none',
                                transform: 'translateY(1px)',
                                bg: 'yellow.300'
                            },
                            variant: 'solid',
                            size: 'md',
                            children: "Diagnose a sample"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Spacer, {}),
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Button, {
                            as: react_.Link,
                            href: 'diags',
                            variant: 'link',
                            colorScheme: 'yellow',
                            size: 'sm',
                            children: "Learn more"
                        })
                    ]
                })
            ]
        })
    }));
};


/***/ })

};
;