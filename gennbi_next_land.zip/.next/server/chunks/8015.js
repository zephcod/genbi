"use strict";
exports.id = 8015;
exports.ids = [8015];
exports.modules = {

/***/ 8015:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ GridListWithCTA)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8930);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__);



const Feature = ({ heading , text  })=>{
    return(/*#__PURE__*/ _jsxs(GridItem, {
        children: [
            /*#__PURE__*/ _jsx(chakra.h3, {
                fontSize: "xl",
                fontWeight: "600",
                children: heading
            }),
            /*#__PURE__*/ _jsx(chakra.p, {
                children: text
            })
        ]
    }));
};
function GridListWithCTA() {
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Container, {
        maxW: "7xl",
        mt: 14,
        p: 4,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Divider, {
                mb: 12
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Stack, {
                spacing: "20px",
                alignContent: 'center',
                align: 'center',
                textAlign: 'center',
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.chakra.h2, {
                        fontSize: "3xl",
                        fontWeight: "700",
                        children: "Assess your project now."
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                        fontSize: "lg",
                        color: 'gray.500',
                        maxW: '2xl',
                        px: 2,
                        align: 'center',
                        children: "Check the pricing for our diagnostic service or start with Gennbi free and get access to our standard tools and pre-construction databases."
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Stack, {
                        direction: {
                            base: 'column',
                            md: 'row'
                        },
                        spacing: 4,
                        alignSelf: 'center',
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                as: _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Link,
                                href: 'http://localhost/gennbi/',
                                colorScheme: "yellow",
                                bgGradient: "linear(yellow.200, yellow.300)",
                                color: 'black',
                                boxShadow: '0px 1px 25px -5px rgb(236 200 50 / 48%), 0 10px 10px -5px rgb(236 200 50 / 43%)',
                                _hover: {
                                    textDecoration: 'none',
                                    transform: 'translateY(1px)',
                                    bg: 'yellow.300'
                                },
                                children: "Start Gennbi Free"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                as: _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Link,
                                href: 'pricing',
                                variant: 'outline',
                                _hover: {
                                    textDecoration: 'none',
                                    transform: 'translateY(1px)'
                                },
                                children: "Check Pricing"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Divider, {
                mt: 12,
                mb: 12
            })
        ]
    }));
};


/***/ })

};
;