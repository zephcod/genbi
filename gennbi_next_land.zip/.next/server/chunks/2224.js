"use strict";
exports.id = 2224;
exports.ids = [2224];
exports.modules = {

/***/ 2224:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ SplitWithImage)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@chakra-ui/react"
var react_ = __webpack_require__(8930);
// EXTERNAL MODULE: external "react-icons/bs"
var bs_ = __webpack_require__(567);
;// CONCATENATED MODULE: ./public/gennbi_enns.jpg
/* harmony default export */ const gennbi_enns = ({"src":"/_next/static/media/gennbi_enns.180ce8d9.jpg","height":720,"width":1280,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABQEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAAhA//xAAeEAACAQMFAAAAAAAAAAAAAAABAgQAExQDERIicv/aAAgBAQABPwCIyYs3Qti1gD2OvPdWFf/EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQIBAT8Af//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQMBAT8Af//Z"});
;// CONCATENATED MODULE: ./pages/sections/column_feature.tsx




const Feature = ({ text , icon , iconBg  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Stack, {
        as: react_.Link,
        direction: 'row',
        align: 'center',
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(react_.Flex, {
                w: 8,
                h: 8,
                align: 'center',
                justify: 'center',
                rounded: 'full',
                bg: iconBg,
                children: icon
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                fontWeight: 600,
                children: text
            })
        ]
    }));
};
function SplitWithImage() {
    return(/*#__PURE__*/ jsx_runtime_.jsx(react_.Container, {
        maxW: '5xl',
        py: 20,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.SimpleGrid, {
            templateColumns: {
                sm: '1fr 1fr',
                md: '2fr 4fr'
            },
            columns: {
                base: 1,
                md: 2
            },
            spacing: 6,
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Stack, {
                    spacing: 4,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Heading, {
                            children: "Engineering neural networks"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Text, {
                            color: 'gray.500',
                            fontSize: 'lg',
                            children: [
                                "Gennbi uses statistical machine learning techniques to give computer systems the ability to learn from data, without being explicitly programmed....",
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Button, {
                                    as: react_.Link,
                                    href: 'enns',
                                    variant: 'link',
                                    colorScheme: 'yellow',
                                    size: 'sm',
                                    children: "Learn more"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Stack, {
                            spacing: 6,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(Feature, {
                                    icon: /*#__PURE__*/ jsx_runtime_.jsx(react_.Icon, {
                                        as: bs_.BsFillLightningChargeFill,
                                        color: (0,react_.useColorModeValue)('yellow.400', 'yellow.200'),
                                        w: 5,
                                        h: 5
                                    }),
                                    iconBg: (0,react_.useColorModeValue)('gray.100', 'gray.700'),
                                    text: 'BIM optimization'
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(Feature, {
                                    icon: /*#__PURE__*/ jsx_runtime_.jsx(react_.Icon, {
                                        as: bs_.BsJournalCheck,
                                        color: (0,react_.useColorModeValue)('yellow.400', 'yellow.200'),
                                        w: 5,
                                        h: 5
                                    }),
                                    iconBg: (0,react_.useColorModeValue)('gray.100', 'gray.700'),
                                    text: 'Constructability review'
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(Feature, {
                                    icon: /*#__PURE__*/ jsx_runtime_.jsx(react_.Icon, {
                                        as: bs_.BsCurrencyDollar,
                                        color: (0,react_.useColorModeValue)('yellow.400', 'yellow.200'),
                                        w: 5,
                                        h: 5
                                    }),
                                    iconBg: (0,react_.useColorModeValue)('gray.100', 'gray.700'),
                                    text: 'Cost estimation control'
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(react_.Flex, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Image, {
                        rounded: 'md',
                        alt: 'Engineering neural networks',
                        objectFit: 'cover',
                        src: gennbi_enns.src
                    })
                })
            ]
        })
    }));
};


/***/ })

};
;