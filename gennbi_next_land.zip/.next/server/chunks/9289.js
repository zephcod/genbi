"use strict";
exports.id = 9289;
exports.ids = [9289];
exports.modules = {

/***/ 9289:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ SimpleAbout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@chakra-ui/react"
var react_ = __webpack_require__(8930);
// EXTERNAL MODULE: ./pages/sections/contact.tsx
var contact = __webpack_require__(2075);
;// CONCATENATED MODULE: ./public/ethiopian_flag.svg
/* harmony default export */ const ethiopian_flag = ({"src":"/_next/static/media/ethiopian_flag.a8d03b42.svg","height":36,"width":36});
// EXTERNAL MODULE: external "react-icons/fa"
var fa_ = __webpack_require__(6290);
;// CONCATENATED MODULE: ./pages/sections/aboutus.tsx





function SimpleAbout() {
    return(/*#__PURE__*/ jsx_runtime_.jsx(react_.Container, {
        mt: '14',
        maxW: 'inherit',
        bg: (0,react_.useColorModeValue)('gray.50', 'gray.900'),
        py: {
            base: 12,
            md: 12
        },
        px: {
            base: 6,
            md: 24
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Stack, {
            spacing: {
                base: 6,
                md: 10
            },
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
                    as: 'header',
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Heading, {
                            lineHeight: 1.1,
                            fontWeight: 600,
                            fontSize: {
                                base: '2xl',
                                sm: '4xl',
                                lg: '5xl'
                            },
                            children: "About Gennbi"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                            color: (0,react_.useColorModeValue)('gray.900', 'gray.400'),
                            fontWeight: 300,
                            fontSize: '2xl',
                            children: "The pre-construction fix"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.SimpleGrid, {
                    templateColumns: {
                        sm: '1fr 1fr',
                        md: '4fr 2fr'
                    },
                    spacing: 10,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Stack, {
                            align: 'flex-start',
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Heading, {
                                    as: "h2",
                                    size: "md",
                                    mt: 6,
                                    mb: 2,
                                    children: "What is Gennbi?"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                    color: 'gray.500',
                                    children: "Gennbi is a pre-construction diagnostics software. It indicates a project’s range of faults and misalignments in calculations, codes, standards and specifications. Our solutions help the construction industry as a whole overcome the toughest challenges in design, financing, and procurement."
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Divider, {}),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Spacer, {}),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Heading, {
                                    as: "h3",
                                    size: "md",
                                    mt: 6,
                                    mb: 2,
                                    children: "Gennbi is mission driven"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                    color: 'gray.500',
                                    children: "Construction is the second industry prone to corruption; only next to mining. Each year 25% of construction budget is lost in terms of cost or schedule overruns. This is in addition to the customary 5-10% contingency amount. Cost and schedule overruns are not the industry’s normal; they are the manifestation of unforeseen errors requiring extra resources/time before proceeding to the next task. Our mission is to eliminate cost and schedule overruns and reduce construction contingencies to less than 5%."
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Divider, {}),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Spacer, {}),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Heading, {
                                    as: "h2",
                                    size: "md",
                                    mt: 6,
                                    mb: 2,
                                    children: "A new approach to pre-construction"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                    color: 'gray.500',
                                    children: "A vast amount of planning takes place before the actual construction begins. From design assessment, to cost estimation and handling contracts, gennbi takes down the pre-construction tasks in a new way. There is no need to fill out complicated forms, Gennbi can assess projects with just photo of the plans. Once the results are generated, consultants and contractors rule out errors and re-run diagnostics until the optimum scenario is achieved. Finally, variables for gennbi’s default market data and forms can be customized to generate a builder informatics that will guide the construction through the whole process."
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Divider, {}),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Spacer, {}),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Heading, {
                                    as: "h2",
                                    size: "md",
                                    mt: 6,
                                    mb: 2,
                                    children: "Our vision for the construction industry"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                    color: 'gray.500',
                                    children: "Gennbi’s builder informatics will play a key role in the advancement of the construction industry into robotics, modularization and on-site autonomous assembly. In simple analogy; as there are compilers for software, our builder informatics compiles the whole construction process in to small chunks of tasks."
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Divider, {}),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Spacer, {}),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.HStack, {
                                    mt: 6,
                                    mb: 2,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Heading, {
                                            as: "h2",
                                            size: "md",
                                            children: "Under the hood"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Image, {
                                            width: 35,
                                            height: 25,
                                            alt: 'Gennbi Logo',
                                            src: ethiopian_flag.src,
                                            display: 'inline'
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
                                    as: 'span',
                                    color: 'gray.500',
                                    d: 'inline',
                                    children: [
                                        "Gennbi is originally created in Ethiopia",
                                        ' ',
                                        "by two brothers,",
                                        ' ',
                                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Icon, {
                                            as: fa_.FaLinkedin,
                                            display: 'inline-flex',
                                            mt: 0
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Link, {
                                            href: 'https://www.linkedin.com/in/amanuel-melesse-1150a0161/',
                                            isExternal: true,
                                            children: "Amanuel"
                                        }),
                                        ' ',
                                        "and",
                                        ' ',
                                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Icon, {
                                            as: fa_.FaLinkedin,
                                            display: 'inline-flex',
                                            mt: 0
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Link, {
                                            href: 'https://www.linkedin.com/in/sofonias-melesse/',
                                            isExternal: true,
                                            children: "Sofonias"
                                        }),
                                        ". Their multi-disciplinary expertise in architecture, computer science, engineering, economics and urban planning is the key to the excellence in the services we provide. The algorithm that fuels Gennbi took a great deal of commitment to reach where we are now and we are further evolving and iterating to deliver the best diagnostics tool for the construction industry."
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Divider, {}),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Spacer, {}),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Heading, {
                                    as: "h2",
                                    size: "md",
                                    mt: 6,
                                    mb: 2,
                                    children: "Work with us"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                    color: 'gray.500',
                                    children: "If you are interested in working with an agile team to develop, customize, integrate, test and maintain web, mobile and desktop-based construction applications built on various technology frameworks we are the right fit for you. Join our growing team to be a part of a brighter future!"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Spacer, {}),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                    color: 'gray.500',
                                    children: "We are looking for self-directed learners who take full responsibility for growth and skill development. We compensate our team very attractively. The ones that delay gratification will reap the best pay-off. In exchange we will hold you accountable to meeting deadlines regardless of normal working hours and take ownership of problems and shepherd the process until resolved; even at the price of other commitments at the extremes."
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Divider, {}),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Spacer, {}),
                                /*#__PURE__*/ jsx_runtime_.jsx(contact["default"], {})
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Stack, {
                            display: {
                                base: 'none',
                                md: 'flex'
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Container, {
                                bg: (0,react_.useColorModeValue)('gray.50', 'gray.900'),
                                width: "md",
                                centerContent: true,
                                overflow: "hidden",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.VStack, {
                                    // maxW="inherit"
                                    spacing: 2,
                                    align: 'flex-start',
                                    bg: (0,react_.useColorModeValue)('white', 'gray.800'),
                                    color: "gray",
                                    borderRadius: "md",
                                    direction: 'row',
                                    // m={{ sm: 2, md: 2, lg: 2 }}
                                    p: {
                                        sm: 2,
                                        md: 2,
                                        lg: 4
                                    },
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Heading, {
                                            p: '4',
                                            as: 'h4',
                                            size: "xl",
                                            children: "Contents here"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Button, {
                                            pl: 8,
                                            variant: 'link',
                                            _hover: {
                                                textDecoration: 'none',
                                                transform: 'translateY(1px)'
                                            },
                                            children: "What is Gennbi?"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Button, {
                                            pl: 8,
                                            variant: 'link',
                                            _hover: {
                                                textDecoration: 'none',
                                                transform: 'translateY(1px)'
                                            },
                                            children: "Gennbi mission"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Button, {
                                            pl: 8,
                                            variant: 'link',
                                            _hover: {
                                                textDecoration: 'none',
                                                transform: 'translateY(1px)'
                                            },
                                            children: "Pre-construction"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Button, {
                                            pl: 8,
                                            variant: 'link',
                                            _hover: {
                                                textDecoration: 'none',
                                                transform: 'translateY(1px)'
                                            },
                                            children: "Gennbi vision"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Button, {
                                            pl: 8,
                                            variant: 'link',
                                            _hover: {
                                                textDecoration: 'none',
                                                transform: 'translateY(1px)'
                                            },
                                            children: "Team"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Button, {
                                            pl: 8,
                                            variant: 'link',
                                            _hover: {
                                                textDecoration: 'none',
                                                transform: 'translateY(1px)'
                                            },
                                            children: "Careers"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Button, {
                                            pl: 8,
                                            variant: 'link',
                                            _hover: {
                                                textDecoration: 'none',
                                                transform: 'translateY(1px)'
                                            },
                                            children: "Contact"
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                })
            ]
        })
    }));
};


/***/ })

};
;