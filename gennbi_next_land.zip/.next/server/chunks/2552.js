"use strict";
exports.id = 2552;
exports.ids = [2552];
exports.modules = {

/***/ 9365:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/gennbi_logo.a165ef4a.svg","height":75,"width":300});

/***/ }),

/***/ 6673:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ LargeWithNewsletter)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8930);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6290);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6652);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_bi__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _chakra_ui_icons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4513);
/* harmony import */ var _chakra_ui_icons__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_chakra_ui_icons__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _public_gennbi_logo_svg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9365);

/* eslint-disable */ 




const SocialButton = ({ children , href  })=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
        bg: (0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.useColorModeValue)('blackAlpha.100', 'whiteAlpha.100'),
        // w={10}
        // h={10}
        cursor: 'pointer',
        as: 'a',
        href: href,
        target: '_blank',
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        transition: 'background 0.3s ease',
        "aria-label": 'Call Segun',
        _hover: {
            bg: (0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.useColorModeValue)('blackAlpha.200', 'whiteAlpha.200')
        },
        children: children
    }));
};
const ListHeader = ({ children  })=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
        fontWeight: '500',
        fontSize: 'lg',
        mb: 2,
        children: children
    }));
};
function LargeWithNewsletter() {
    const { colorMode , toggleColorMode  } = (0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.useColorMode)();
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Box, {
        bg: (0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.useColorModeValue)('gray.50', 'gray.900'),
        color: (0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.useColorModeValue)('gray.700', 'gray.200'),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Container, {
            as: _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Stack,
            maxW: '7xl',
            py: 10,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.SimpleGrid, {
                templateColumns: {
                    sm: '1fr 1fr',
                    md: '2fr 1fr 1fr 1fr'
                },
                spacing: 10,
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Stack, {
                        spacing: 2,
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Image, {
                                            width: 150,
                                            height: 35,
                                            alt: 'Gennbi Logo',
                                            src: _public_gennbi_logo_svg__WEBPACK_IMPORTED_MODULE_5__/* ["default"].src */ .Z.src
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Spacer, {}),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                        onClick: toggleColorMode,
                                        children: colorMode === 'light' ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_icons__WEBPACK_IMPORTED_MODULE_4__.MoonIcon, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_icons__WEBPACK_IMPORTED_MODULE_4__.SunIcon, {})
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                fontSize: 'sm',
                                children: "2022 Gennbi."
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Divider, {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                fontSize: 'md',
                                children: "Subscribe to our newsletter."
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Stack, {
                                direction: 'row',
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Input, {
                                        placeholder: 'Your email address',
                                        bg: (0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.useColorModeValue)('blackAlpha.100', 'whiteAlpha.100'),
                                        border: 0,
                                        _focus: {
                                            bg: 'blackAlpha.200'
                                        }
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.IconButton, {
                                        bg: (0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.useColorModeValue)('yellow.300', 'yellow.300'),
                                        color: (0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.useColorModeValue)('white', 'gray.800'),
                                        _hover: {
                                            bg: 'yellow.400'
                                        },
                                        "aria-label": "Subscribe",
                                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bi__WEBPACK_IMPORTED_MODULE_3__.BiMailSend, {})
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Stack, {
                                direction: 'row',
                                spacing: 6,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SocialButton, {
                                        href: 'https://www.linkedin.com/company/gennbi',
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Icon, {
                                            as: react_icons_fa__WEBPACK_IMPORTED_MODULE_2__.FaLinkedin
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SocialButton, {
                                        href: 'https://www.youtube.com/channel/UCGZxkkizB8i7D-npzJmqIhQ',
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Icon, {
                                            as: react_icons_fa__WEBPACK_IMPORTED_MODULE_2__.FaYoutube
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SocialButton, {
                                        href: 'https://www.facebook.com/Gennbicom',
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Icon, {
                                            as: react_icons_fa__WEBPACK_IMPORTED_MODULE_2__.FaFacebook
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SocialButton, {
                                        href: '#',
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Icon, {
                                            as: react_icons_fa__WEBPACK_IMPORTED_MODULE_2__.FaTelegram
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                        fontSize: 'sm',
                                        alignSelf: 'flex-end',
                                        children: "info@gennbi.com"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Stack, {
                        align: 'flex-start',
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ListHeader, {
                                children: 'Company'
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                as: _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Link,
                                variant: 'link',
                                _hover: {
                                    textDecoration: 'none',
                                    transform: 'translateY(1px)'
                                },
                                href: 'about',
                                children: "About us"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                as: _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Link,
                                variant: 'link',
                                _hover: {
                                    textDecoration: 'none',
                                    transform: 'translateY(1px)'
                                },
                                href: 'about',
                                children: "Careers"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                as: _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Link,
                                variant: 'link',
                                _hover: {
                                    textDecoration: 'none',
                                    transform: 'translateY(1px)'
                                },
                                href: 'about',
                                children: "Contact us"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                as: _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Link,
                                variant: 'link',
                                _hover: {
                                    textDecoration: 'none',
                                    transform: 'translateY(1px)'
                                },
                                href: 'pricing',
                                children: "Pricing"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                as: _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Link,
                                variant: 'link',
                                _hover: {
                                    textDecoration: 'none',
                                    transform: 'translateY(1px)'
                                },
                                href: 'privacy',
                                children: "Privacy Policy"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                as: _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Link,
                                variant: 'link',
                                _hover: {
                                    textDecoration: 'none',
                                    transform: 'translateY(1px)'
                                },
                                href: 'terms',
                                children: "Terms and conditions"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Stack, {
                        align: 'flex-start',
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ListHeader, {
                                children: 'Gennbi'
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                as: _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Link,
                                variant: 'link',
                                _hover: {
                                    textDecoration: 'none',
                                    transform: 'translateY(1px)'
                                },
                                href: 'casestudies',
                                children: "Case Studies"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                as: _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Link,
                                variant: 'link',
                                _hover: {
                                    textDecoration: 'none',
                                    transform: 'translateY(1px)'
                                },
                                href: '#',
                                children: "Contributors"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                as: _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Link,
                                variant: 'link',
                                _hover: {
                                    textDecoration: 'none',
                                    transform: 'translateY(1px)'
                                },
                                href: 'howitworks',
                                children: "How Gennbi woks"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                as: _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Link,
                                variant: 'link',
                                _hover: {
                                    textDecoration: 'none',
                                    transform: 'translateY(1px)'
                                },
                                href: 'enns',
                                children: "Enginnering assessments"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                as: _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Link,
                                variant: 'link',
                                _hover: {
                                    textDecoration: 'none',
                                    transform: 'translateY(1px)'
                                },
                                href: 'bis',
                                children: "Builder Informatics"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                as: _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Link,
                                variant: 'link',
                                _hover: {
                                    textDecoration: 'none',
                                    transform: 'translateY(1px)'
                                },
                                href: 'workflows',
                                children: "Workflows"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Stack, {
                        align: 'flex-start',
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ListHeader, {
                                children: 'Support'
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                as: _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Link,
                                variant: 'link',
                                _hover: {
                                    textDecoration: 'none',
                                    transform: 'translateY(1px)'
                                },
                                href: 'blog',
                                children: "Blogs"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                as: _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Link,
                                variant: 'link',
                                _hover: {
                                    textDecoration: 'none',
                                    transform: 'translateY(1px)'
                                },
                                href: 'documentation',
                                children: "Documentation"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                as: _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Link,
                                variant: 'link',
                                _hover: {
                                    textDecoration: 'none',
                                    transform: 'translateY(1px)'
                                },
                                href: 'downloads',
                                children: "Downloads"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                as: _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Link,
                                variant: 'link',
                                _hover: {
                                    textDecoration: 'none',
                                    transform: 'translateY(1px)'
                                },
                                href: 'faq',
                                children: "FAQs"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                as: _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Link,
                                variant: 'link',
                                _hover: {
                                    textDecoration: 'none',
                                    transform: 'translateY(1px)'
                                },
                                href: 'gettingstarted',
                                children: "Getting started"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                as: _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Link,
                                variant: 'link',
                                _hover: {
                                    textDecoration: 'none',
                                    transform: 'translateY(1px)'
                                },
                                href: 'help',
                                children: "Help center"
                            })
                        ]
                    })
                ]
            })
        })
    }));
};


/***/ }),

/***/ 201:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ WithSubnavigation)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8930);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _chakra_ui_icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4513);
/* harmony import */ var _chakra_ui_icons__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_chakra_ui_icons__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _public_gennbi_logo_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9365);




function WithSubnavigation() {
    const { isOpen , onToggle  } = (0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.useDisclosure)();
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Box, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                as: 'header',
                bg: (0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.useColorModeValue)('gray.50', 'gray.900'),
                color: (0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.useColorModeValue)('gray.600', 'white'),
                minH: '60px',
                w: '100%',
                position: 'fixed',
                zIndex: 200,
                // boxSize={'full'}
                // pos={'relative'}
                py: {
                    base: 2
                },
                px: {
                    base: 2
                },
                justify: 'center',
                align: 'center',
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                        flex: {
                            base: 1,
                            md: 'auto'
                        },
                        ml: {
                            base: -2
                        },
                        display: {
                            base: 'flex',
                            md: 'none'
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.IconButton, {
                            onClick: onToggle,
                            icon: isOpen ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_icons__WEBPACK_IMPORTED_MODULE_2__.CloseIcon, {
                                w: 3,
                                h: 3
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_icons__WEBPACK_IMPORTED_MODULE_2__.HamburgerIcon, {
                                w: 5,
                                h: 5
                            }),
                            variant: 'ghost',
                            "aria-label": 'Toggle Navigation'
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                        flex: {
                            base: 1
                        },
                        justify: {
                            base: 'center',
                            md: 'start'
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.LinkBox, {
                            _hover: {
                                transform: 'translateY(1px)'
                            },
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.LinkOverlay, {
                                href: "/",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Image, {
                                    width: 150,
                                    height: 35,
                                    alt: 'Gennbi Logo',
                                    src: _public_gennbi_logo_svg__WEBPACK_IMPORTED_MODULE_3__/* ["default"].src */ .Z.src
                                })
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Stack, {
                        flex: {
                            base: 1,
                            md: 0
                        },
                        justify: 'flex-end',
                        direction: 'row',
                        spacing: 6,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                                display: {
                                    base: 'none',
                                    md: 'flex'
                                },
                                ml: 10,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(DesktopNav, {})
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                colorScheme: "yellow",
                                bgGradient: "linear(yellow.200, yellow.300)",
                                color: 'black',
                                as: _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Link,
                                href: 'http://localhost/gennbi/',
                                fontWeight: 500,
                                _hover: {
                                    textDecoration: 'none',
                                    transform: 'translateY(1px)',
                                    bg: 'yellow.300'
                                },
                                variant: 'solid',
                                size: 'md',
                                mr: 4,
                                children: "Get Started"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Collapse, {
                in: isOpen,
                animateOpacity: true,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(MobileNav, {})
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Divider, {})
        ]
    }));
};
const DesktopNav = ()=>{
    const linkColor = (0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.useColorModeValue)('gray.600', 'gray.200');
    const linkHoverColor = (0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.useColorModeValue)('yellow.500', 'yellow.300');
    const popoverContentBgColor = (0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.useColorModeValue)('white', 'gray.800');
    var _href;
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Stack, {
        direction: 'row',
        spacing: 4,
        children: NAV_ITEMS.map((navItem)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Box, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Popover, {
                    trigger: 'hover',
                    placement: 'bottom-start',
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.PopoverTrigger, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Link, {
                                display: {
                                    base: 'none',
                                    md: 'inline-flex'
                                },
                                p: 2,
                                href: (_href = navItem.href) !== null && _href !== void 0 ? _href : '#',
                                fontSize: 'l',
                                fontWeight: 400,
                                color: linkColor,
                                _hover: {
                                    transform: 'translateY(1px)',
                                    textDecoration: 'none',
                                    color: linkHoverColor
                                },
                                children: navItem.label
                            })
                        }),
                        navItem.children && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.PopoverContent, {
                            borderTop: '2px',
                            borderTopColor: 'yellow.300',
                            boxShadow: 'xl',
                            bg: popoverContentBgColor,
                            p: 4,
                            rounded: 'xl',
                            minW: 'sm',
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Stack, {
                                children: navItem.children.map((child)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(DesktopSubNav, {
                                        ...child
                                    }, child.label)
                                )
                            })
                        })
                    ]
                })
            }, navItem.label)
        )
    }));
};
const DesktopSubNav = ({ label , href , subLabel  })=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Link, {
        href: href,
        role: 'group',
        display: 'block',
        p: 2,
        rounded: 'md',
        _hover: {
            boxShadow: 'inner',
            bg: (0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.useColorModeValue)('gray.50', 'gray.900')
        },
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Stack, {
            direction: 'row',
            align: 'center',
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Box, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                            transition: 'all .3s ease',
                            _groupHover: {
                                color: (0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.useColorModeValue)('yellow.400', 'yellow.200')
                            },
                            fontWeight: 500,
                            children: label
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                            fontSize: 'sm',
                            children: subLabel
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                    transition: 'all .3s ease',
                    transform: 'translateX(-10px)',
                    opacity: 0,
                    _groupHover: {
                        opacity: '100%',
                        transform: 'translateX(0)'
                    },
                    justify: 'flex-end',
                    align: 'center',
                    flex: 1
                })
            ]
        })
    }));
};
const MobileNav = ()=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Stack, {
        bg: (0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.useColorModeValue)('white', 'gray.800'),
        p: 4,
        display: {
            md: 'none'
        },
        children: NAV_ITEMS.map((navItem)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(MobileNavItem, {
                ...navItem
            }, navItem.label)
        )
    }));
};
const MobileNavItem = ({ label , children , href  })=>{
    const { isOpen , onToggle  } = (0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.useDisclosure)();
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Stack, {
        spacing: 4,
        onClick: children && onToggle,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                py: 2,
                as: _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Link,
                href: href !== null && href !== void 0 ? href : '#',
                justify: 'space-between',
                align: 'center',
                _hover: {
                    textDecoration: 'none'
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                        fontWeight: 600,
                        color: (0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.useColorModeValue)('gray.600', 'gray.200'),
                        children: label
                    }),
                    children && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Icon, {
                        as: _chakra_ui_icons__WEBPACK_IMPORTED_MODULE_2__.ChevronDownIcon,
                        transition: 'all .25s ease-in-out',
                        transform: isOpen ? 'rotate(180deg)' : '',
                        w: 6,
                        h: 6
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Collapse, {
                in: isOpen,
                animateOpacity: true,
                style: {
                    marginTop: '0!important'
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Stack, {
                    mt: 2,
                    pl: 4,
                    borderLeft: 1,
                    borderStyle: 'solid',
                    borderColor: (0,_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.useColorModeValue)('gray.200', 'gray.700'),
                    align: 'start',
                    children: children && children.map((child)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Link, {
                            py: 2,
                            href: child.href,
                            children: child.label
                        }, child.label)
                    )
                })
            })
        ]
    }));
};
const NAV_ITEMS = [
    {
        label: 'Solutions',
        children: [
            {
                label: 'Engineering Neural Networks',
                subLabel: 'Trending Design to inspire you',
                href: 'enns'
            },
            {
                label: 'Builder Infromatics',
                subLabel: 'Construction informatics + techniques',
                href: 'bis'
            },
            {
                label: 'How GENNBI works',
                href: 'howitworks'
            }, 
        ]
    },
    {
        label: 'Resources',
        children: [
            {
                label: 'Downloads',
                subLabel: 'Applications and plugins',
                href: 'downloads'
            },
            {
                label: 'Getting Started',
                subLabel: 'Instructions to get you up and running',
                href: 'gettingstarted'
            },
            {
                label: 'Blog',
                href: 'blog'
            }
        ]
    },
    {
        label: 'Pricing',
        href: 'pricing'
    },
    {
        label: 'About',
        href: 'about'
    }, 
];


/***/ })

};
;