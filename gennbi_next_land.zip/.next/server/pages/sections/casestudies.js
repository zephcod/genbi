"use strict";
(() => {
var exports = {};
exports.id = 5471;
exports.ids = [5471,3433,7297,7907,4884,5170,8656,6121,8912,480,1089,1727,5979,9094,7640,2488];
exports.modules = {

/***/ 4513:
/***/ ((module) => {

module.exports = require("@chakra-ui/icons");

/***/ }),

/***/ 8930:
/***/ ((module) => {

module.exports = require("@chakra-ui/react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [5338], () => (__webpack_exec__(5338)));
module.exports = __webpack_exports__;

})();