"use strict";
(() => {
var exports = {};
exports.id = 4884;
exports.ids = [4884,7297,7907,6121,5979];
exports.modules = {

/***/ 8930:
/***/ ((module) => {

module.exports = require("@chakra-ui/react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [1789], () => (__webpack_exec__(1789)));
module.exports = __webpack_exports__;

})();