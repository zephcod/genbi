"use strict";
(() => {
var exports = {};
exports.id = 2031;
exports.ids = [2031,3433,2923,5471,9150,7297,7907,4884,5170,4980,6220,5485,9382,8656,3008,6121,8999,8912,480,1089,1727,5979,9094,7640,2488];
exports.modules = {

/***/ 4513:
/***/ ((module) => {

module.exports = require("@chakra-ui/icons");

/***/ }),

/***/ 8930:
/***/ ((module) => {

module.exports = require("@chakra-ui/react");

/***/ }),

/***/ 567:
/***/ ((module) => {

module.exports = require("react-icons/bs");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [7404,1852,1311], () => (__webpack_exec__(1311)));
module.exports = __webpack_exports__;

})();