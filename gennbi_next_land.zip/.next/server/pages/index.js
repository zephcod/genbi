"use strict";
(() => {
var exports = {};
exports.id = 5405;
exports.ids = [5405,364,3433,2923,5471,1931,9150,7297,7907,4884,5170,4980,6220,5485,9382,8656,3008,6121,8999,8912,2031,480,1089,1727,5979,9094,4493,7640,2488];
exports.modules = {

/***/ 8501:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@chakra-ui/react"
var react_ = __webpack_require__(8930);
;// CONCATENATED MODULE: ./public/hero.png
/* harmony default export */ const hero = ({"src":"/_next/static/media/hero.ce8ab99a.png","height":550,"width":527,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA+klEQVR42mMAgftHm5lB9JfrvcGvLk599fnGnJP/3/QIM4DAxNoEJhBdm50svmRy3udZncn/F08q/L9lZvHBA1VCLAxNlXlgBbMnNctmZ6T9SkiO/zt5ctv/eXP6NzCAwNb5JYx7lxazg9j5se5LijPC/i+e3///5OGNLgzooLYgtrO3POT/hln5k0D8LVPCmRm2r+sT+3Rj7oI189uvbN64/Pe2NbP+H9w0c3nr1f8sDCCweUZZzs2tJf93rWj7v275rP+H9m/9c/TAlv8H96w7CpRmZNgzO3bWrV2l/y/tn/uro73m/7qV0/5fPLH115F9a/+f2DmrAgDUaHvzKAqcgwAAAABJRU5ErkJggg=="});
// EXTERNAL MODULE: ./pages/sections/modaldemo.tsx
var modaldemo = __webpack_require__(1852);
;// CONCATENATED MODULE: ./components/hero.tsx




function SplitScreen() {
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Stack, {
        mt: '14',
        minH: '100vh',
        direction: {
            base: 'column',
            md: 'column',
            lg: 'row'
        },
        bg: (0,react_.useColorModeValue)('gray.50', 'gray.900'),
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(react_.Flex, {
                flex: 1,
                justify: 'center',
                children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Image, {
                    alt: 'Login Image',
                    objectFit: 'cover',
                    src: hero.src
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(react_.Flex, {
                p: 8,
                flex: 1,
                align: 'center',
                justify: 'center',
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Stack, {
                    spacing: 6,
                    w: 'full',
                    maxW: 'lg',
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Heading, {
                            fontSize: {
                                base: '3xl',
                                md: '4xl',
                                lg: '5xl'
                            },
                            lineHeight: 1.1,
                            fontWeight: 600,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                    as: 'span',
                                    position: 'relative',
                                    children: "Gennbi,"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                ' ',
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                    as: 'span',
                                    children: "A pre-construction fix!"
                                }),
                                ' '
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                            fontSize: {
                                base: 'md',
                                lg: 'lg'
                            },
                            color: 'gray.500',
                            children: "Avoid more than 75% of errors on a construction project by diagnosing them before commencing any job."
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Stack, {
                            direction: {
                                base: 'column',
                                md: 'row'
                            },
                            spacing: 4,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Button, {
                                    as: react_.Link,
                                    href: 'downloads',
                                    colorScheme: "yellow",
                                    bgGradient: "linear(yellow.200, yellow.300)",
                                    color: 'black',
                                    boxShadow: '0px 1px 25px -5px rgb(236 200 50 / 48%), 0 10px 10px -5px rgb(236 200 50 / 43%)',
                                    _hover: {
                                        textDecoration: 'none',
                                        bg: 'yellow.300',
                                        transform: 'translateY(1px)'
                                    },
                                    children: "Download Gennbi"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(modaldemo["default"], {})
                            ]
                        })
                    ]
                })
            })
        ]
    }));
};

// EXTERNAL MODULE: ./components/navbar.tsx
var navbar = __webpack_require__(201);
// EXTERNAL MODULE: ./components/footer.tsx
var footer = __webpack_require__(6673);
// EXTERNAL MODULE: ./pages/sections/hero_feature.tsx
var hero_feature = __webpack_require__(8074);
// EXTERNAL MODULE: ./pages/sections/stats.tsx
var stats = __webpack_require__(4089);
// EXTERNAL MODULE: ./pages/sections/column_feature.tsx + 1 modules
var column_feature = __webpack_require__(2224);
// EXTERNAL MODULE: ./pages/sections/column2_feature.tsx + 1 modules
var column2_feature = __webpack_require__(2924);
// EXTERNAL MODULE: ./pages/sections/herovideo.tsx
var herovideo = __webpack_require__(8161);
// EXTERNAL MODULE: ./pages/sections/cta_headline.tsx + 1 modules
var cta_headline = __webpack_require__(1789);
// EXTERNAL MODULE: ./pages/sections/cta2.tsx
var cta2 = __webpack_require__(8015);
;// CONCATENATED MODULE: ./pages/index.tsx












function Home() {
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(navbar/* default */.Z, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(SplitScreen, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(cta_headline["default"], {}),
            /*#__PURE__*/ jsx_runtime_.jsx(herovideo["default"], {}),
            /*#__PURE__*/ jsx_runtime_.jsx(column_feature["default"], {}),
            /*#__PURE__*/ jsx_runtime_.jsx(hero_feature["default"], {}),
            /*#__PURE__*/ jsx_runtime_.jsx(column2_feature["default"], {}),
            /*#__PURE__*/ jsx_runtime_.jsx(stats["default"], {}),
            /*#__PURE__*/ jsx_runtime_.jsx(cta2["default"], {}),
            /*#__PURE__*/ jsx_runtime_.jsx(footer/* default */.Z, {})
        ]
    }));
};


/***/ }),

/***/ 4513:
/***/ ((module) => {

module.exports = require("@chakra-ui/icons");

/***/ }),

/***/ 8930:
/***/ ((module) => {

module.exports = require("@chakra-ui/react");

/***/ }),

/***/ 6652:
/***/ ((module) => {

module.exports = require("react-icons/bi");

/***/ }),

/***/ 567:
/***/ ((module) => {

module.exports = require("react-icons/bs");

/***/ }),

/***/ 6290:
/***/ ((module) => {

module.exports = require("react-icons/fa");

/***/ }),

/***/ 9989:
/***/ ((module) => {

module.exports = require("react-icons/io5");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2552,7404,1852,1789,2924,2224,8161,4089,8015,8074], () => (__webpack_exec__(8501)));
module.exports = __webpack_exports__;

})();